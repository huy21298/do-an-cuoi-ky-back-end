(function($) 
{
    var methods = {
        isDownloadDropbox: function(){
            return $(this).jplayerExtension.options.downloadType=='dropbox';
        },

        setDownloadType: function(type) {
            if(['dropbox', 'computer'].indexOf(type)<0)
                return;
            $(this).jplayerExtension.options.downloadType = type;
        },

        customDownload: function(atag){
            var email = '';
            $.ajax({
                url: "/ui/_system/get_account_info_dropbox.php",
                data: {downloadType: '1'},
                method: 'GET'
            }).done(function(temp_email) {
                email = temp_email;
                $( "#dropbox-tranfer-message .content" ).html('Starting transfer to Dropbox.com: '+temp_email+'<span class="de">Start der Übertragung zum Dropbox Account: '+temp_email+'</span>');
            });

            setTimeout(function() {
                if (email != '') {
                    if (navigator.userAgent.match(/(iPod|iPhone|iPad)/)) {
                        $( "#dropbox-tranfer-message" ).dialog( "open" );
                        $(this).jplayerExtension.options.downloadType = 'dropbox';
                        $('#txt_choose_device').text(': Dropbox');
                        $(self).trigger('beforeDownload');
                    }
                    var downloadUrl = $(atag).attr('href');
                    var downloadType = $(this).jplayerExtension.options.downloadType;
                    $.ajax({
                        url: downloadUrl,
                        data: {downloadType: downloadType},
                        method: 'GET'
                    }).done(function(d) {
                        if($(self).jplayerExtension("isDownloadDropbox")){
                            $( "#dropbox-tranfer-message .content" ).html('Transfer completed<span class="de">Transfer abgeschlossen</span>');
                            $( "#dropbox-tranfer-message" ).dialog( "open" );
                            setTimeout(function() {
                                $( "#dropbox-tranfer-message .content" ).html('Starting transfer to Dropbox.com: ...<span class="de">Start der Übertragung zum Dropbox Account: ...</span>');
                                $( "#dropbox-tranfer-message" ).dialog( "close" );
                            }, 5000);
                        }
                    });
                } else {
                    $( "#message-enter-info-dropbox" ).dialog( "open" );
                }
            },3500);
        },

        activateDownloads: function()
        {       
            var dlMp3 = false;
            var dlWav = false;
            var self = this;

            //Downloadlinks wiederherstellen
            for(var i = 0; i < $(this).jplayerExtension.options.songlist.length; i++)
            {
                if($(this).jplayerExtension.options.songlist[i].downloadMp3) {
                    dlMp3 = true;
                    $('.jp-free-media').eq(i).find('a.jp-playlist-item-free:first').unbind("click").attr("href", "/ui/_system/dlv20.php?mid=" + 
                        $(this).jplayerExtension.options.mid + "&uid=" + $(this).jplayerExtension.options.uid + "&songtype=mp3&songid="+$(this).jplayerExtension.options.songlist[i].songid+"&pcode="+$(this).jplayerExtension.options.pcode+"&ac="+$(this).jplayerExtension.options.activationCode).removeClass("inactive").click(function(event){
                                    
                            if (!navigator.userAgent.match(/(iPod|iPhone|iPad)/) || $(self).jplayerExtension("isDownloadDropbox")) 
                            {
                                $(self).trigger('beforeDownload');

                                event.stopImmediatePropagation();
                                $(".dl-allsongs.m1, .dl-allsongs.m2").each(function() {
                                    $(this).attr("href", "javascript:void(0);");
                                    $(this).removeAttr('target');
                                    $(this).css('cursor','default');
                                    $(this).unbind('click');
                                    $(this).find('img').attr('src',$(self).jplayerExtension.options.xPixelPath);
                                });

                                if($(self).jplayerExtension("isDownloadDropbox")){
                                    $(self).jplayerExtension("customDownload", this);
                                    return false;
                            }
                            }
                            else {
                                alert("Download is currently not supported for this device.");
                                return false;
                            }                           
                        });;
                }
                else {
                    var tmp = $('.jp-free-media').eq(i).find('a.jp-playlist-item-free:first');
                    tmp.addClass("inactive");   
                    tmp.attr("href", "javascript:void(0);");
                    tmp.removeAttr('target');
                    tmp.css('cursor','default');
                    tmp.unbind('click');
                    tmp.find('img').attr('src',$(self).jplayerExtension.options.xPixelPath);
                    
                }
                
                if($(this).jplayerExtension.options.songlist[i].downloadWav) {
                    dlWav = true;
                    $('.jp-free-media').eq(i).find('a.jp-playlist-item-free:last').unbind("click").attr("href", "/ui/_system/dlv20.php?mid=" + 
                        $(this).jplayerExtension.options.mid + "&uid=" + $(this).jplayerExtension.options.uid + "&songtype=wav&songid="+$(this).jplayerExtension.options.songlist[i].songid+"&pcode="+$(this).jplayerExtension.options.pcode+"&ac="+$(this).jplayerExtension.options.activationCode).removeClass("inactive").click(function(event){
                            if (!navigator.userAgent.match(/(iPod|iPhone|iPad)/) || $(self).jplayerExtension("isDownloadDropbox")) 
                            {
                                $(self).trigger('beforeDownload');

                                event.stopImmediatePropagation();
                                $(".dl-allsongs.m1, .dl-allsongs.m2").each(function() {
                                    $(this).attr("href", "javascript:void(0);");
                                    $(this).removeAttr('target');
                                    $(this).css('cursor','default');
                                    $(this).unbind('click');
                                    $(this).find('img').attr('src',$(self).jplayerExtension.options.xPixelPath);
                                });

                                if($(self).jplayerExtension("isDownloadDropbox")){
                                    $(self).jplayerExtension("customDownload", this);
                                    return false;
                            }
                            }
                            else {
                                alert("Download is currently not supported for this device.");
                                return false;
                            }                           
                        });;
                }
                else {
                    var tmp = $('.jp-free-media').eq(i).find('a.jp-playlist-item-free:last');
                    tmp.addClass("inactive");   
                    tmp.attr("href", "javascript:void(0);");
                    tmp.removeAttr('target');
                    tmp.css('cursor','default');
                    tmp.unbind('click');
                    tmp.find('img').attr('src',$(self).jplayerExtension.options.xPixelPath);                 
                }
            }
            //////////////////////////////////////////////////////
            // download bundle 
            //////////////////////////////////////////////////////
            if (dlMp3) {                
                $('.dl-allsongs.m2').bind("click").attr("href", "/ui/_system/dlv20.php?mid=" + $(this).jplayerExtension.options.mid + "&uid=" + $(this).jplayerExtension.options.uid + "&songtype=mp3&songid=allmp3&pcode="+$(this).jplayerExtension.options.pcode+"&ac="+$(this).jplayerExtension.options.activationCode).click(function(event){
                    
                    if (!navigator.userAgent.match(/(iPod|iPhone|iPad)/) || $(self).jplayerExtension("isDownloadDropbox")) 
                    {                       
                        $(self).trigger('beforeDownload');

                        event.stopImmediatePropagation();

                        if($(self).jplayerExtension("isDownloadDropbox")){
                            $(self).jplayerExtension("customDownload", this);
                            return false;
                    }
                    }
                    else {
                        alert("Download is currently not supported for this device.");
                        return false;
                    }                           
                });
            }
            if (dlWav) {
                $('.dl-allsongs.w2').bind("click").attr("href", "/ui/_system/dlv20.php?mid=" + $(this).jplayerExtension.options.mid + "&uid=" + $(this).jplayerExtension.options.uid + "&songtype=wav&songid=allwav&pcode="+$(this).jplayerExtension.options.pcode+"&ac="+$(this).jplayerExtension.options.activationCode).click(function(event){
                    if (!navigator.userAgent.match(/(iPod|iPhone|iPad)/) || $(self).jplayerExtension("isDownloadDropbox")) 
                    {                       
                        $(self).trigger('beforeDownload');

                        event.stopImmediatePropagation();

                        if($(self).jplayerExtension("isDownloadDropbox")){
                            $(self).jplayerExtension("customDownload", this);
                            return false;
                    }
                    }
                    else {
                        alert("Download is currently not supported for this device.");
                        return false;
                    }                           
                });             
            }           
        },      
        feedbackSent : function()
        {
            //Downloads aktivieren
            $(this).jplayerExtension("activateDownloads");
            
            //Formular resetten
            $($(this).jplayerExtension.options.feedback).find("textarea").val("");
            $($(this).jplayerExtension.options.feedback).find("input[type=hidden]").val("");
            $($(this).jplayerExtension.options.feedback).children("form").hide();
            $($(this).jplayerExtension.options.feedback).append("<p class=\"info\">" + $(this).jplayerExtension.options.sendFeedbackMessage + "</p>");
            $(this).jplayerExtension.options.hasSendFeedback = true;
        },
        getFile : function(songid, type)
        {
            for(var i = 0; i < $(this).jplayerExtension.options.songlist.length; i++)
            {
                if ($(this).jplayerExtension.options.songlist[i].songid == songid)
                {
                    if (type == "mp3")
                    {
                        return $(this).jplayerExtension.options.songlist[i].mp3;
                    }else
                    {
                        return $(this).jplayerExtension.options.songlist[i].oga;
                    }
                }
            }
            
            return "javascript:void(0);";
        },
        checkFeedback : function() {

            //hasRatedAlbum: (($(this).jplayerExtension.options).ratingValue == 0) ? false : true,
            if(($(this).jplayerExtension.options).ratingValue > 0) {
                $(jplayerExtension_cObj).jplayerExtension.hasRatedAlbum = true;
            }
            
            //console.log(($(this).jplayerExtension.options).ratingValue);
            
            if ($('#feedback > form').find("textarea").val() == "" || $('#feedback > form').find("textarea").val() == "undefined" || $('#feedback > form').find("textarea").val() == null || 
                $('#feedback > form').find("textarea").val().replace(/^\s+/, '').replace(/\s+$/, '') == '' || 
                $('#feedback > form').find("textarea").val() == 'Please enter your comment here...' || 
                !$(jplayerExtension_cObj).jplayerExtension.hasRatedAlbum || !$(jplayerExtension_cObj).jplayerExtension.hasRatedSong)
                {
                    var error = "";
                    
                    if ($('#feedback > form').find("textarea").val() == "" || $('#feedback > form').find("textarea").val() == "undefined" || $('#feedback > form').find("textarea").val() == null || 
                        $('#feedback > form').find("textarea").val().replace(/^\s+/, '').replace(/\s+$/, '') == '' || 
                        $('#feedback > form').find("textarea").val() == 'Please enter your comment here...')
                    {           
                        error = "enter a feedback";                     
                    }
                    
                    if (!$(jplayerExtension_cObj).jplayerExtension.hasRatedAlbum)
                    {
                        if (error != "")
                        {
                            error += " and ";
                        }
                        
                        error += "rate the album";
                    }
                    
                    if (!$(jplayerExtension_cObj).jplayerExtension.hasRatedSong)
                    {
                        if (error != "")
                        {
                            error += " and ";
                        }
                        
                        error += "rate a song";
                    }
                    
                    alert("Please " + error);
                }
                else {

          if($(jplayerExtension_cObj).find(".jp-playlist li").length == 1) {
              song_id = $(jplayerExtension_cObj).find(".jp-playlist li span.id_songid").html();
              $.ajax({
                                type: "POST",
                                url: "/ui/_system/save_favourite-v20.php",
                                data: {mid: $(this).jplayerExtension.options.mid, uid: $(this).jplayerExtension.options.uid, pcode: $(this).jplayerExtension.options.pcode, cno: $(this).jplayerExtension.options.cno, value: 1, songid: song_id},
                                success: function(data) {
                                }
                            });
            }

                    var comment = $($(this).jplayerExtension.options.feedbackComment).val();
                    var ratingValue = $('#rating_value').text();
                    //Formdaten als AJAX Request        
                    $.ajax({
                        type: "POST",
                        url: "/ui/_system/save_rating.php",
                        data:{comment: comment, mid: $(this).jplayerExtension.options.mid, uid: $(this).jplayerExtension.options.uid, pcode: $(this).jplayerExtension.options.pcode, cno: $(this).jplayerExtension.options.cno, value: ratingValue},
                        success: function(data)
                        {                       
                            //Formular resetten
                            $(jplayerExtension_cObj).jplayerExtension("feedbackSent");                          
                            $(jplayerExtension_cObj).jplayerExtension.hasSendedFeedback = true;
                        }
                    });
                }
            
        },
        checkFeedbackSingleDownload : function() {
            
            var error = "";

            if($(jplayerExtension_cObj).jplayerExtension.options.feedbackNeeded) {
                
                if(!$(jplayerExtension_cObj).jplayerExtension.hasSendedFeedback)
                {           
                    error = "enter a feedback";                     
                }
                
                if (!$(jplayerExtension_cObj).jplayerExtension.hasRatedAlbum)
                {
                    if (error != "")
                    {
                        error += " and ";
                    }
                    
                    error += "rate the album";
                }
                
                if (!$(jplayerExtension_cObj).jplayerExtension.hasRatedSong)
                {
                    if (error != "")
                    {
                        error += " and ";
                    }
                    
                    error += "rate a song";
                }
            }
            if(error != "") { 
                alert("Please " + error); 
                return false;
            }
            else {
                return true;            
            }
        },
        checkFeedbackDownloadAll : function() {
            
            var error = "";
            if($(jplayerExtension_cObj).jplayerExtension.options.feedbackNeeded) {
                
                if(!$(jplayerExtension_cObj).jplayerExtension.hasSendedFeedback)
                {           
                    error = "enter a feedback";                     
                }
                
                if (!$(jplayerExtension_cObj).jplayerExtension.hasRatedAlbum)
                {
                    if (error != "")
                    {
                        error += " and ";
                    }
                    
                    error += "rate the album";
                }
                
                if (!$(jplayerExtension_cObj).jplayerExtension.hasRatedSong)
                {
                    if (error != "")
                    {
                        error += " and ";
                    }
                    
                    error += "rate a song";
                }
            }
            if(error == "") {

                $('.jp-playlist-item-free').each(function(i, obj) {
                    $(this).attr("href", "javascript:void(0);");
                    $(this).removeAttr('target');
                    $(this).css('cursor','default');    
                    $(this).addClass('inactive');
                    $(this).unbind('click');
                });                 
                return true;
            }
            else {
                alert("Please " + error);
                return false;
            }
        },
    
        init : function(options) {      
            jplayerExtension_cObj = this;           
            $(this).jplayerExtension.options = $.extend($(this).jplayerExtension("getDefaultSettings"), options);
            
            $(this).jplayerExtension.playlist = new jPlayerPlaylist({
                jPlayer: $(this).jplayerExtension.options.jplayer,
                cssSelectorAncestor: $(this).jplayerExtension.options.cssSelectorAncestor
            }, $(this).jplayerExtension.options.songlist, {
                swfPath: '/ui/_system/html5/js/jplayer/Jplayer.swf',
                solution: 'html, flash', // Valid solutions: html, flash. Order defines priority. 1st is highest,
                supplied: 'mp3', // Defines which formats jPlayer will try and support and the priority by the order. 1st is highest,
                preload: 'metadata',  // HTML5 Spec values: none, metadata, auto.
                volume: 0.9, // The volume. Number 0 to 1.
                muted: false,
                wmode: "window", // Valid wmode: window, transparent, opaque, direct, gpu.
                smoothPlayBar: true,
                keyEnabled: true,
                xPixelPath: $(self).jplayerExtension.options.xPixelPath,
                downloadIcon: $(this).jplayerExtension.options.downloadIcon,
                feedbackNeeded: $(this).jplayerExtension.options.feedbackNeeded,
                ready: $(this).jplayerExtension("playerReady")
            });

            $(this).jplayerExtension.rating = $($(this).jplayerExtension.options.jrating).raty({
                starOff: $(this).jplayerExtension.options.starsPath.off,
                starOn: $(this).jplayerExtension.options.starsPath.on,
                score: $(this).jplayerExtension.options.ratingValue,
                click: function(score, evt) {
                    if($(this).jplayerExtension.options.viewOnly) return false;
                    //$(this).raty('readOnly', true);
                    $('#rating_value').html(score);
                    //$(jplayerExtension_cObj).jplayerExtension.hasRatedAlbum = true;
                    $.ajax({
                        type: "POST",
                        url: "/ui/_system/save_rating_value.php",
                        data: {mid: $(this).jplayerExtension.options.mid, uid: $(this).jplayerExtension.options.uid, pcode: $(this).jplayerExtension.options.pcode, cno: $(this).jplayerExtension.options.cno, value: score},
                        success: function() {
                            $(jplayerExtension_cObj).jplayerExtension.hasRatedAlbum = true;
                        }
                    });
                }
            });
            
            //Validierung des Feedback Formulars
            $("#feedback > form").submit(function() {
                if($(this).jplayerExtension.options.viewOnly) return false;
                $(this).jplayerExtension("checkFeedback");
                return false;
            });                             
        },
        initExt : function()
        {       
            
            var self = this;
            //Hängt an der Playlist die Favorite Funktion an und übergibt beim auswählen der Songs die Song IDs
            //an das Feedback Formular
            $($(this).jplayerExtension.options.jplaylist).find(".jp-playlist-item").each(function(index, element){          
                if ($(jplayerExtension_cObj).jplayerExtension.options.songlist[index] != null)
                {
                    
                    //Download Links (de)aktivieren                 
                    if ($(jplayerExtension_cObj).jplayerExtension.options.songlist[index].free && $(jplayerExtension_cObj).jplayerExtension.options.feedbackNeeded)
                    {
                        
                    }else
                    {            
                        //Direct Download
                        if ($(this).jplayerExtension.options.songlist[index].downloadMp3) {
                            $(element).siblings(".jp-free-media").children(".jp-playlist-item-free:first").attr("href", "/ui/_system/dlv20.php?mid=" + $(this).jplayerExtension.options.mid + "&uid=" + $(this).jplayerExtension.options.uid + "&songtype=mp3&songid="+$(this).jplayerExtension.options.songlist[index].songid+"&pcode="+$(this).jplayerExtension.options.pcode+"&ac="+$(this).jplayerExtension.options.activationCode).click(function(event){
                                // @author Tam(8-4-2015)
                                // save fav
                                $.ajax({
                                    type: "POST",
                                    url: "/ui/_system/save_favourite-v20.php",
                                    data: {mid: $(this).jplayerExtension.options.mid, uid: $(this).jplayerExtension.options.uid, pcode: $(this).jplayerExtension.options.pcode, cno: $(this).jplayerExtension.options.cno, value: 1, songid: $(this).jplayerExtension.options.songlist[index].songid},
                                    success: function(data) {
                                    }
                                });

                                if (!navigator.userAgent.match(/(iPod|iPhone|iPad)/) || $(self).jplayerExtension("isDownloadDropbox")) 
                                {
                                    $(self).trigger('beforeDownload');

                                    event.stopImmediatePropagation();
                                    $(".dl-allsongs.m1, .dl-allsongs.m2").each(function() {
                                        $(this).attr("href", "javascript:void(0);");
                                        $(this).removeAttr('target');
                                        $(this).css('cursor','default');
                                        $(this).unbind('click');
                                        $(this).find('img').attr('src',$(self).jplayerExtension.options.xPixelPath);
                                    });

                                    if($(self).jplayerExtension("isDownloadDropbox")){
                                        $(self).jplayerExtension("customDownload", this);
                                        return false;
                                    }
                                }
                                else {
                                    //alert("Download is currently not supported for this device.5");
                                    //return false;
                                    var r = confirm("To download files on a mobile device, you need to connect a Dopbox account. Do you want to do that now?");
                                    if (r == true) {
                                        //do ok
                                        var authorizeUrl = $('#authorizeUrl').val();

                                        window.open(authorizeUrl, "DropBoxAuthorizeWindow", "width=600,height=400");

                                        event.stopImmediatePropagation();
                                        $(".dl-allsongs.m1, .dl-allsongs.m2").each(function() {
                                            $(this).attr("href", "javascript:void(0);");
                                            $(this).removeAttr('target');
                                            $(this).css('cursor','default');
                                            $(this).unbind('click');
                                        $(this).find('img').attr('src','/ui/xpixel.gif');
                                    });
                                        $(self).jplayerExtension("customDownload", this);
                                    } else {
                                        //do nothing
                                }
                                    return false;
                                }
                            });
                        }
                        if ($(this).jplayerExtension.options.songlist[index].downloadWav) {
                            $(element).siblings(".jp-free-media").children(".jp-playlist-item-free:last").attr("href", "/ui/_system/dlv20.php?mid=" + $(this).jplayerExtension.options.mid + "&uid=" + $(this).jplayerExtension.options.uid + "&songtype=wav&songid="+$(this).jplayerExtension.options.songlist[index].songid + "&pcode="+$(this).jplayerExtension.options.pcode+"&ac="+$(this).jplayerExtension.options.activationCode).click(function(event){
                                // @author Tam(8-4-2015)
                                // save fav
                                $.ajax({
                                    type: "POST",
                                    url: "/ui/_system/save_favourite-v20.php",
                                    data: {mid: $(this).jplayerExtension.options.mid, uid: $(this).jplayerExtension.options.uid, pcode: $(this).jplayerExtension.options.pcode, cno: $(this).jplayerExtension.options.cno, value: 1, songid: $(this).jplayerExtension.options.songlist[index].songid},
                                    success: function(data) {
                                    }
                                });
                                
                                if (!navigator.userAgent.match(/(iPod|iPhone|iPad)/) || $(self).jplayerExtension("isDownloadDropbox"))
                                {
                                    $(self).trigger('beforeDownload');

                                    event.stopImmediatePropagation();
                                    $(".dl-allsongs.w1, .dl-allsongs.w2").each(function() {
                                        $(this).attr("href", "javascript:void(0);");
                                        $(this).removeAttr('target');
                                        $(this).css('cursor','default');
                                        $(this).unbind('click');
                                        $(this).find('img').attr('src',$(self).jplayerExtension.options.xPixelPath);
                                    });

                                    if($(self).jplayerExtension("isDownloadDropbox")){
                                        $(self).jplayerExtension("customDownload", this);
                                        return false;
                                    }
                                }
                                else {
                                    //alert("Download is currently not supported for this device.");
                                    //return false;
                                    var r = confirm("To download files on a mobile device, you need to connect a Dopbox account. Do you want to do that now?");
                                    if (r == true) {
                                        //do ok
                                        var authorizeUrl = $('#authorizeUrl').val();

                                        window.open(authorizeUrl, "DropBoxAuthorizeWindow", "width=600,height=400");

                                        event.stopImmediatePropagation();
                                        $(".dl-allsongs.m1, .dl-allsongs.m2").each(function() {
                                            $(this).attr("href", "javascript:void(0);");
                                            $(this).removeAttr('target');
                                            $(this).css('cursor','default');
                                            $(this).unbind('click');
                                        $(this).find('img').attr('src','/ui/xpixel.gif');
                                    });
                                        $(self).jplayerExtension("customDownload", this);
                                    } else {
                                        //do nothing
                                }
                                    return false;
                                }
                            });
                        }
                    }
                    
                    //Prüfen ob für mindestens ein Song gerated wurde
                    if ($(jplayerExtension_cObj).jplayerExtension.options.songlist[index].isFavorite)
                    {
                        $(jplayerExtension_cObj).jplayerExtension.hasRatedSong = true;
                    }
                    
                    //MP3 Download entfernen, wenn nicht erwünscht
                    if (!$(jplayerExtension_cObj).jplayerExtension.options.songlist[index].downloadMp3)
                    {
                        var tmp = $(element).siblings(".jp-free-media").children(".jp-playlist-item-free:first");                   
                        tmp.attr("href", "javascript:void(0);");
                        tmp.removeAttr('target');
                        tmp.css('cursor','default');
                        tmp.addClass("inactive");                   
                        tmp.unbind('click');
                    }
                    
                    //WAV Download entfernen, wenn nicht erwünscht
                    if (!$(jplayerExtension_cObj).jplayerExtension.options.songlist[index].downloadWav)
                    {                       
                        var tmp = $(element).siblings(".jp-free-media").children(".jp-playlist-item-free:last");        
                        tmp.attr("href", "javascript:void(0);");
                        tmp.removeAttr('target');
                        tmp.css('cursor','default');                    
                        tmp.addClass("inactive");
                        tmp.unbind('click');
                    }
                }
            });
            
            // check for feedback single download
            $('.jp-playlist-item-free.feedbackNeeded').bind("click", function() {                 
                $(this).jplayerExtension("checkFeedbackSingleDownload");
            });
            // check for feedback bundle download
            $('.dl-allsongs').click(function(event) {
                if (!navigator.userAgent.match(/(iPod|iPhone|iPad)/) || $(self).jplayerExtension("isDownloadDropbox")) {
                    event.stopImmediatePropagation();
                    if($(this).jplayerExtension("checkFeedbackDownloadAll")){
                        $(self).trigger('beforeDownload');

                        if($(self).jplayerExtension("isDownloadDropbox")){
                            $(self).jplayerExtension("customDownload", this);
                            return false;
                        }
                        return true;
                    }
                }else {
                    alert("Download is currently not supported for this device.");
                }
                return false;
            });
            
            
            
            //Focus-Blur Verhalten des Feedbackfeldes, weil Label im Textarea steht
            $($(this).jplayerExtension.options.feedback).find("textarea").focus(function(){
                if ($(this).val() == $(jplayerExtension_cObj).jplayerExtension.options.feedbackLabel)
                {
                    $(this).val("");
                }
            });
            
            $($(this).jplayerExtension.options.feedback).find("textarea").blur(function(){
                if ($(this).val() == "")
                {
                    $(this).val($(jplayerExtension_cObj).jplayerExtension.options.feedbackLabel);
                }
            });
            
            if ($(this).jplayerExtension.options.hasSendFeedback)
            {
                $(this).jplayerExtension("feedbackSent");
            }
            
            // Download einzeln deaktivieren
            $.each( $(jplayerExtension_cObj).jplayerExtension.options.songlist, function( key, value ) {
                if(!value.downloadMp3) {

                    var tmp = $('#jp-playlist-item-'+value.songid).siblings(".jp-free-media").children(".jp-playlist-item-free:first");             
                    tmp.attr("href", "javascript:void(0);");
                    tmp.removeAttr('target');
                    tmp.css('cursor','default');                    
                    tmp.addClass("inactive");
                    tmp.unbind('click');
                }
                if(!value.downloadWav) {
                    var tmp = $('#jp-playlist-item-'+value.songid).siblings(".jp-free-media").children(".jp-playlist-item-free:last");              
                    tmp.attr("href", "javascript:void(0);");
                    tmp.removeAttr('target');
                    tmp.css('cursor','default');                    
                    tmp.addClass("inactive");
                    tmp.unbind('click');
                }
            });
            
            // Sicherheitshalber nochmal global nachfragen
            //WAV Download entfernen, wenn nicht erwünscht
            if ($(this).jplayerExtension.options.generalWav == '0')
            {
                $('.jp-playlist-item').each(function() {
                    var tmp = $(this).siblings(".jp-free-media").children(".jp-playlist-item-free:last");               
                    tmp.attr("href", "javascript:void(0);");
                    tmp.removeAttr('target');
                    tmp.css('cursor','default');                    
                    tmp.addClass("inactive");
                    tmp.unbind('click');
                });
            }
            
            //MP3 Download entfernen, wenn nicht erwünscht
            if ($(this).jplayerExtension.options.generalMp3 == '0')
            {
                $('.jp-playlist-item').each(function() {
                    var tmp = $(this).siblings(".jp-free-media").children(".jp-playlist-item-free:first");              
                    tmp.attr("href", "javascript:void(0);");
                    tmp.removeAttr('target');
                    tmp.css('cursor','default');                    
                    tmp.addClass("inactive");
                    tmp.unbind('click');
                });
            }
            
            
        },
        getDefaultSettings : function()
        {
            return {
                jplayer: "#jquery_jplayer_1",
                cssSelectorAncestor: "#jp_container_1",
                jrating: ".jrating",
                starsPath: {
                    off: "/ui/_system/html5/images/raty/star-off-small.png",
                    on: "/ui/_system/html5/images/raty/star-on-small.png"
                },
                xPixelPath: '/ui/xpixel.gif',
                feedback: "#feedback", //oder welcher Kommentar ?
                feedbackComment: "#feedback textarea", //oder welcher Kommentar ?
                jplaylist: ".jp-playlist",
                songlist: false,
                favorite: {
                    label: "Favorite"
                },
                hasSendFeedback: false,
                feedbackNeeded: false,
                ratingValue: 0,
                feedbackLabel: "Please enter your comment here..."
            };
        },
        playerReady : function()
        {
            setTimeout(function(){
                $(jplayerExtension_cObj).jplayerExtension("initExt");
            }, 500);                
        },
        selectSong : function(index, element)
        {
            if($(this).jplayerExtension.options.viewOnly) return false;
            if ($(this).jplayerExtension.options.songlist[index] != null)
            {
                $('#player div.jp-audio div.jp-type-playlist div.jp-time-holder').css('display','inline');
                
                $($(this).jplayerExtension.options.feedback).find("input[name=songid]").val($(this).jplayerExtension.options.songlist[index].songid);               
                
                if ($(this).jplayerExtension.options.feedback)
                {
                    $($(this).jplayerExtension.options.feedback).show();                    
                }else
                {
                    $($(this).jplayerExtension.options.feedback).children("form").hide();
                }               

                $.ajax({
                    type: "POST",
                    url: "/ui/_system/update_listened_song.php",
                    data: {mid: $(this).jplayerExtension.options.mid, uid: $(this).jplayerExtension.options.uid, pcode: $(this).jplayerExtension.options.pcode, cno: $(this).jplayerExtension.options.cno}
                });
                
                $(this).jplayerExtension.songSelected = true;
                
                $('div.jp-playlist ul li').eq(index).addClass('jp-playlist-current');
                
                return true;
            }
        }
    };
    
    $.fn.jplayerExtension = function(method)
    {
        var options;
        var playlist;
        var rating;
        var hasRatedAlbum;
        var hasRatedSong;
        var hasSendedFeedback = false;
        var songSelected = false;
        
        // Method calling logic
        if ( methods[method] ) {
          return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
        } else if ( typeof method === "object" || ! method ) {
          return methods.init.apply( this, arguments );
        } else {
          $.error( "Method " +  method + " does not exist on jQuery.jquery.jplayer.jplayerExtension" );
        }    
    };
    
})(jQuery);