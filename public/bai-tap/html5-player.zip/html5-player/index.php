<?php
header("Location: https://www.hearthemusic.de");
exit;
